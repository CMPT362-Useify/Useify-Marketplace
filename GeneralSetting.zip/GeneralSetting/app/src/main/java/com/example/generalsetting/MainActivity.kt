package com.example.generalsetting

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.content_main)
    }

    fun changeUsername(view : View){
        val intent = Intent(this, Username::class.java)
        startActivity(intent)
    }

    fun changePassword(view: View){
        val intent = Intent(this, Password::class.java)
        startActivity(intent)
    }
}